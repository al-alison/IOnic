export class Fila{
    id:	number;
    nome_fila: string;
    }