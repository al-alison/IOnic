export class Chamado{
    desc: string;
    dataAb: string;
    status: string;
    dataFec: string;

    constructor(desc, dataA, dataF, status){
        this.desc = desc;
        this.status = status;
        this.dataAb = dataA;
        this.dataFec = dataF;
    }
}