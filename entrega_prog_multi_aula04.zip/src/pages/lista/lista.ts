import { Component } from '@angular/core';
import { NavController, DateTime } from 'ionic-angular';
import { Chamado } from '../../Entity/Chamado';

@Component({
  selector: 'page-lista',
  templateUrl: 'lista.html'
})
export class listaPage {
  items:Chamado[] = [
    new Chamado('Troca de HD','25/03/2018','','Aberto'),
    new Chamado('Reset de senha','25/03/2018','22/01/2018','Fechado'),
    new Chamado('Instalação de programa','25/03/2018','','Aberto'),
    new Chamado('Solicitação de acesso','25/03/2018','15/01/2017','Fechado'),
    new Chamado('Criação de regra de firewall','25/03/2018','','Aberto')
  ];/*
  
  items = [
    'Pokémon Yellow',
    'Super Metroid',
    'Mega Man X',
    'The Legend of Zelda',
    'Pac-Man',
    'Super Mario World',
    'Street Fighter II',
    'Half Life',
    'Final Fantasy VII',
    'Star Fox',
    'Tetris',
    'Donkey Kong III',
    'GoldenEye 007',
    'Doom',
    'Fallout',
    'GTA',
    'Halo'
  ];*/
  
  itemSelected(item: string) {
    console.log("Selected Item", item);
  }
  constructor(public navCtrl: NavController) {

  }
}
